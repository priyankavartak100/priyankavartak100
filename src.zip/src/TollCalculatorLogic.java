/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
import com.google.gson.Gson;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.javatuples.Triplet;

public class TollCalculatorLogic {

    public static void main(String[] args) {
        System.out.println("Hi welcome to tollcalculator!!!");
        try {

            FileReader reader = new FileReader("C:\\Priyanka\\407ETR_Test\\interchanges.json");
            Gson gson = new Gson();
            Locations locations = gson.fromJson(reader, Locations.class);
            locations.getLocations().forEach((k, v) -> v.setId(k));
            Integer starting_point_id = 0;
            Integer end_point_id = 0;
            List<Route> connectingRouteList = new ArrayList<>();
            //System.out.println(locations);
            String start_point = "Dundas Street";
            String end_point = "Bronte Road";
            for (RouteDetails routeDetails : locations.getLocations().values()) {
                if (routeDetails.getName().equalsIgnoreCase(start_point)) {
                    starting_point_id = routeDetails.getId();
                };

                if (routeDetails.getName().equalsIgnoreCase(end_point)) {
                    end_point_id = routeDetails.getId();
                };
            };
            for (RouteDetails routeDetails : locations.getLocations().values()) {
                if (Objects.equals(starting_point_id, routeDetails.getId())) {
                    routeDetails.getRoutes().forEach((routeobj) -> {
                        connectingRouteList.add(routeobj);
                    });
                    RouteExt route = nextRoute(connectingRouteList, end_point_id, routeDetails);
                };
            }
            System.out.println("connectingRouteList: " + connectingRouteList);
            System.out.println("starting_point_id: " + starting_point_id);
            System.out.println("end_point_id: " + end_point_id);

            // Integer start_id = locations.getLocations().values().
            // int end_id = data.locations.Values.Where(x =  > x.name == end).FirstOrDefault().id;
        } catch (Exception e) {
            System.out.println("Error..." + e);
        }

    }
    static List<Triplet<Integer, RouteDetails, Route>> routes = new ArrayList<Triplet<Integer, RouteDetails, Route>>();

    static RouteExt nextRoute(List<Route> connectingRouteList, Integer end_point_id, RouteDetails routeDetails) {
        try {
            RouteExt routeExt = new RouteExt();
            for (Route route : connectingRouteList) {
                if (end_point_id == route.getToId()) {
                    Triplet<Integer, RouteDetails, Route> tuple
                            = new Triplet(end_point_id, routeDetails, route);
                    routes.add(tuple);
                    routeExt.setRoute(route);
                    routeExt.setRouteDetails(routeDetails);
                    routeExt.setId(end_point_id);

                } else {
                    routeExt = nextRoute(connectingRouteList, end_point_id, routeDetails);
                    if (routeExt != null) {
                        return routeExt;
                    }
                }
                return routeExt;
            }
            System.out.println(routeExt);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
